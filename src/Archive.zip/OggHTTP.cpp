#include "OggHTTP.h"


OggHTTPClient::OggHTTPClient(OggHTTPWorker& server, StreamSocket& sockStream) 
:server(server)
,sock(sockStream)
{
}

OggHTTPClient::~OggHTTPClient() {
}

void OggHTTPClient::run() {
	printf("Running client\n");	
	char tmp_buffer[4096];
	while(true) {
		printf("client thread running ....\n");
		
		int received = sock.receiveBytes(tmp_buffer, 4096);
		if(received > 0) { 
			printf("added: %d bytes\n", received);
			std::copy(
				 tmp_buffer
				,tmp_buffer + received
				,std::back_inserter(buffer)
			);
			
			 std::copy(
				buffer.begin()
				,buffer.end()
				,std::ostream_iterator<char>(std::cout,"")
			);
		}
		
		// check we have data we need to send
		if(buffer.size() > 0) {
			printf("We need to send: %lu bytes\n", buffer.size());
			int to_send = buffer.size();
			int sent = sock.sendBytes(&buffer[0], to_send);
			to_send -= sent;
			while(to_send > 0) {
				int done = sock.sendBytes(&buffer[sent], to_send);				
				sent+=done;
				to_send -=done;
			}
		}
		//Thread::sleep(500);
	}
}


void OggHTTPClient::sendToClient(ogg_page* page) {
	mutex.lock();
	send_buffer.push_back(page);
	//std::copy(data, data+size, std::back_inserter(buffer));
	mutex.unlock();
}

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

OggHTTPWorker::OggHTTPWorker() {
}

OggHTTPWorker::~OggHTTPWorker() {
}

void OggHTTPWorker::setup(int nPort) {
	port = nPort;
}

void OggHTTPWorker::run() {
	printf("Start listening at %d\n", port);
	sock = new ServerSocket(port);
	while(true) {
		printf("sleep...\n");
		StreamSocket client_sock = sock->acceptConnection();
		OggHTTPClient* client_connection = new OggHTTPClient(*this, client_sock);
		printf("connection\n");
		clients.push_back(client_connection);
		Thread* client_thread = new Thread();
		
		client_threads.insert(std::pair<Thread*, OggHTTPClient*>(client_thread, client_connection));
		client_thread->start(*client_connection);
		Thread::sleep(500);
	}
}

void OggHTTPWorker::sendToClients(ogg_page* page) {
	vector<OggHTTPClient*>::iterator it = clients.begin();
}

void OggHTTPWorker::shutdown() {
}

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

OggHTTP::OggHTTP() {
}

OggHTTP::~OggHTTP() {
	worker.shutdown();
	thread.join();
}


void OggHTTP::setup(int w, int h, int bytesPerSecond, int nPort) {
	port = nPort;
	width = w;
	height = h;
	bps = bytesPerSecond;
	worker.setup(port);
	
	th_info_init(&theora_info);    
	theora_info.frame_width = ((w + 15) >>4)<<4; // why (?)
    theora_info.frame_height = ((h + 15)>>4)<<4; // why (?)
    theora_info.pic_width = w;
    theora_info.pic_height = h;
    theora_info.pic_x = 0;
    theora_info.pic_y = 0;
	theora_info.colorspace = TH_CS_UNSPECIFIED;
    theora_info.pixel_fmt = TH_PF_420;
    theora_info.fps_numerator = 25;
    theora_info.fps_denominator = 1;
    theora_info.aspect_numerator = 1;
    theora_info.aspect_denominator = 1;
    theora_info.target_bitrate = 8000;
    // info.keyframe_granule_shift = 0;
	
	// context to work with.
	// -----------------------
	theora_context = th_encode_alloc(&theora_info);  
	if(!theora_context) {
		printf("Error: cannot create context.\n");
		exit(1);
	}	
    th_info_clear(&theora_info);
	
	
	// Add obligatory headers
	// ---------------------
	th_comment comment;
	th_comment_init(&comment);
	th_comment_add(&comment, (char *)"openFrameworks");
	comment.vendor = (char *)"openFrameworks";
	
	
	ogg_stream_init(&ogg_stream, rand());
	while (th_encode_flushheader(theora_context, &comment, &header_packet) > 0) {
		ogg_stream_packetin(&ogg_stream, &header_packet);
		while (ogg_stream_pageout(&ogg_stream, &header_page)) {
		}
	}
	 
	// rest of headers... before creating a new page.
	while (ogg_stream_flush(&ogg_stream, &header_page) > 0) {
	}
	
	
	// Setup conversion objects
	// ------------------------
	yuv_w = w;
	yuv_h = h;

	yuv_w = (w + 15) & ~15;
	yuv_h = (h + 15) & ~15;
  
	ycbcr[0].width = yuv_w;
	ycbcr[0].height = yuv_h;
	ycbcr[0].stride = yuv_w;
	ycbcr[1].width = (yuv_w >> 1);
	ycbcr[1].stride = ycbcr[1].width;
	ycbcr[1].height = (yuv_h >> 1);
	ycbcr[2].width = ycbcr[1].width;
	ycbcr[2].stride = ycbcr[1].stride;
	ycbcr[2].height = ycbcr[1].height;
	
	
	// @todo free buffers
	ycbcr[0].data = yuv_y = (unsigned char*)malloc(ycbcr[0].stride * ycbcr[0].height);
	ycbcr[1].data = yuv_u = (unsigned char*)malloc(ycbcr[1].stride * ycbcr[1].height);
	ycbcr[2].data = yuv_v = (unsigned char*)malloc(ycbcr[2].stride * ycbcr[2].height);
	
	
	// context used to convert RGB->YUV
	convert_context = sws_getContext(
		w
		,h
		,PIX_FMT_RGB24
		,w
		,h
		,PIX_FMT_YUV420P
		,SWS_FAST_BILINEAR
		,NULL
		,NULL
		,NULL
	);

	if(convert_context == NULL) {
		printf("Error: cannot get convert context\n");
		exit(1);
	}

	in_image = vpx_img_alloc(NULL, VPX_IMG_FMT_RGB24, width, height, 0);
	//out_planes = {ycbcr[0].data, ycbcr[1].data, ycbcr[2].data};
	out_planes[0] = ycbcr[0].data;
	out_planes[1] = ycbcr[1].data;
	out_planes[2] = ycbcr[2].data;

//	int out_strides[3] = {ycbcr[0].stride, ycbcr[1].stride, ycbcr[2].stride};
	out_strides[0] = ycbcr[0].stride;
	out_strides[1] = ycbcr[1].stride;
	out_strides[2] = ycbcr[2].stride;

	line_size = w * 3;	

	printf("created ogg stream\n");
}

void OggHTTP::start() {
	thread.start(worker);
}

void OggHTTP::sendToClients(unsigned char* pixels) {
	
	in_image = vpx_img_wrap(
		in_image
		,VPX_IMG_FMT_RGB24
		,width
		,height
		,0
		,pixels
	);
	
	int output_slice_h = sws_scale(
		 convert_context
		,in_image->planes
		,in_image->stride
		,0
		,height
		,out_planes
		,out_strides
	);	
	
	int enc_result = th_encode_ycbcr_in(theora_context, ycbcr);
	if(enc_result == TH_EFAULT) {
		fprintf(stderr, "error: could not encode frame\n");
		exit(1);
	}
	
	ogg_page* oggpage = new ogg_page();
	ogg_packet oggpacket;
	int last = 0;
	while(th_encode_packetout(theora_context, last, &oggpacket) > 0) {
		ogg_stream_packetin(&ogg_stream, &oggpacket);
		while(ogg_stream_pageout(&ogg_stream, oggpage)) {
		}
	}
	worker.sendToClients(oggpage);		
	//buffered_pages.push_back(oggpage);

}